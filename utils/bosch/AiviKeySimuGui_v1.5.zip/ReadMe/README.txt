Graphical User Interface for VD_Input TTFis Commands (Key, SWC, Touch, etc.)

===============================================================================================
Version 1.5
- Added CAMERA key in the PIVI Simulator
- Added MEX key for Renault in AIVI and Portrait  Simulator
===============================================================================================

===============================================================================================
Version 1.4
- Screen Timing adjustment update few ms  delay added to  refresh per cycle. So that rending 
  is proper for Potrait, Renault and PIVI. 
- Changed Screeenshot in PIVI to take Full Resolution Screenshots 1280x768
- Added HVAC climate and MEx hardkeys in PIVISimuGui
===============================================================================================

Version 1.3
- Added SWC_ENTER in AiviKeySimu
- Created New AiviKeyPotraitSimu with Resolution as 820x1024
- Added Menu and Audi HKs in PIVI.
- Added JOYSTICK_MENU_OK in PIVISimuGui
===============================================================================================

Version 1.2
- Added SWC_LEFT and SWC_RIGHT
-Corrected internal naming of HK_HOME for making it work.
===============================================================================================

Version 1.1
- Changed Aivi Theme, Added qss stylesheet in resources file
- Version 1.1 for PIVI Added.

===============================================================================================
Version 0.7
  - Changed name of 3 keys in Design and Main window files: (To match TTFIS names of these keys)
    HK_VOLUME -> HK_RN_VOLUME, HK_VOLUME_UP -> HK_RN_VOLUME_UP, HK_VOLUME_DOWN -> HK_RN_VOLUME_DOWN
  - Optimised minute update timing for screen.

===============================================================================================

Version 0.6
 - Added Key illumination ON and OFF Toggle Radio Switch
===============================================================================================

Version 0.5
	- LSIM Support for Touch and Screen Update has been added by Nguyen Y (RBVH/ENG2).
	- Added Renault additional Keys.
	- Update UI for this tool.

===============================================================================================
Version 0.4

New Features Added:-
- Added IT Commander simulation support
- Added Check Box to Select Target Key Config.
  * User shall First Configure Target with proper PD for key mapping.
  * Then whenever user Selects the checkbox Target Key Config, only configured keys get Enabled
    and remaining keys get disabled.
  * When User Unselects the checkbox Target Key Config, All Keys Get Enabled. 

================================================================================================
Version: 0.3

Installation:
-------------
Unzip the archive to any local path of your choice. The executable "AiviKeySimuGui.exe"
can be started from there without further installation.


Dependencies:
-------------
- TTFis Installation and target setup for AIVI (working)
- SSH (PuTTY) setup for remote access to AIVI target via TCP/IP (working)


Execution:
----------
As this tool is a GUI for the VD_Input TTFis commands, TTFis needs to be running with a
connection to the target (including loading of corresponding TRC files).

TTFis needs to be started in advance!!!

Start executable "AiviKeySimuGui.exe"


Features:
---------
* Simulation of all abstract Hard Key events (including long press).
* Simulation of all Steering Wheel Switches
* Simulation of Left/Right Encoders
* Update of the Target Screen content in the GUI (every 5s). Update can be disabled via
  tool menu.
* Save Screenshot to user directory ("My Pictures")
* Syncronisation of current target volume with left encoder (BETA).


Known limitations:
------------------
* The IT Commander simulation is not yet supported.
* The syncronisation of current target volume feature is in a BETA state. Problems 
  are known in case of target reset or change of trace configuration in the target.
* After a target reset, it takes some time until screen update and key simulation is
  working again.


Command Line Options:
---------------------
Usage: AiviKeySimuGui.exe [options]

Options:
  -h, --help            show this help message and exit
  -t TRACEDEVICE, --tracedevice=TRACEDEVICE
                        TTFis Trace Device, default: <gen3flex@dlt>
  -s SERVER, --ssh=SERVER
                        SSH Server to use for Screenshot, default: 172.17.0.1
  --loglevel=LOGLEVEL   logging level, default: 20, debug is 10
  --logpath=LOGPATH     path to log file, default: stdout  


FAQs:
-----
Q: I have found an issue! OR I have a good idea how to improve the tool!
   To whom can I address this?

A: Please send an E-Mail to:
   Sandeep.Gupta@in.bosch.com
   Alexander.Neufeld@de.bosch.com
   Frank.Gilbert@de.bosch.com


Q: I have found a severe issue! How can I support the analysis?

A: Please start the executable with apptional command line options: 
   "AiviKeySimuGui.exe --loglevel=10 logpath=~\Desktop"
   This command will create logfile on you desktop. Please attach this to your e-mail
   with your problem description.

   
Q: I want to use this tool together with LSIM. 

A: Please start the executable with apptional command line options:  
   "AiviKeySimuGui.exe --tracedevice=gen3flex@dltlsim --ssh=172.17.0.11"
